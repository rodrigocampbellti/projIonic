import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Product } from 'src/app/model/product';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-perfil',
  templateUrl: './product-perfil.page.html',
  styleUrls: ['./product-perfil.page.scss'],
})
export class ProductPerfilPage implements OnInit {

  constructor(
    private productService: ProductService,
    private alertController: AlertController,
    private activatedRouter: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.getParam()
  }

  product = new Product;
  _id: string | null = null;
  imageSrc: string | undefined;

  getParam() {
    this._id = this.activatedRouter.snapshot.paramMap.get("id");
    if (this._id) {
      this.productService.get(this._id).then(async res => {
        this.product = <Product>res;
        if (this.product.fotos) {
          await this.productService.getProtoPerfil(this.product.fotos).then(res => {
            this.imageSrc = res
               })
        } else {
          this.imageSrc = "assets/caixapreta.jpg";
          } 
          } )
}
}
}
