export class Product {
    _id: string = "";
    nome: string = "";
    categoria: string = "";
    descricao: string = "";
    quant: number = 0;
    valor: number = 0;
    fotos: string = "";
    ativo: boolean = true;


}
